# Security Policy

- Never commit `.env` or credentials.
- Keep external adapters disabled unless credentials are supplied locally.
- Default to mock mode and localhost.
- Never force-push, destructively reset, or delete user work.
- Preserve device authorization and read-only safety gates.
