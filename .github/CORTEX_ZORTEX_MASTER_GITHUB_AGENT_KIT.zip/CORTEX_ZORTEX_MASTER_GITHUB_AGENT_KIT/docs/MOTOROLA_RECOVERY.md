# Motorola Recovery

- Stuck at `>`: press `Ctrl+C`.
- `(END)`: press `q`.
- New terminal: `cd /workspaces/YOUR_REPOSITORY && source .venv/bin/activate`.
- Resume: `bash scripts/resume_check.sh`.
