#!/usr/bin/env bash
set -euo pipefail
echo "CORTEX preflight"
git rev-parse --is-inside-work-tree >/dev/null
echo "Repository: $(basename "$(git rev-parse --show-toplevel)")"
echo "Branch: $(git branch --show-current)"
python --version 2>/dev/null || true
git --version
command -v copilot >/dev/null 2>&1 && echo "Copilot CLI: available" || echo "Copilot CLI: missing"
git status --short
