#!/usr/bin/env bash
set -euo pipefail
PROMPT_FILE="${1:-prompts/MASTER_AUTONOMOUS_BUILD_PROMPT.txt}"
command -v copilot >/dev/null 2>&1 || { echo "BLOCKED: terminal AI agent 'copilot' is unavailable."; exit 1; }
[ -f "$PROMPT_FILE" ] || { echo "BLOCKED: prompt file missing: $PROMPT_FILE"; exit 1; }
git rev-parse --is-inside-work-tree >/dev/null
echo "Starting repository-scoped autonomous build..."
copilot --autopilot --no-ask-user -p "$(cat "$PROMPT_FILE")"
