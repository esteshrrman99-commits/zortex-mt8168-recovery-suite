#!/usr/bin/env bash
set -euo pipefail
echo "Branch: $(git branch --show-current)"
git --no-pager log -5 --oneline
git status --short
if [ -f pyproject.toml ] || [ -d tests ]; then pytest -q --maxfail=1 || true; fi
