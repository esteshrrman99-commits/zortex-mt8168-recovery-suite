# Local App Platform Scaffold

Run `python app_platform/backend/app.py`.

Defaults: localhost only, mock mode, read-only, no credentials, no external API calls.
