from http.server import BaseHTTPRequestHandler,HTTPServer
import json
class H(BaseHTTPRequestHandler):
 def do_GET(self):
  data={"status":"ok","mode":"mock","read_only":True}
  body=json.dumps(data).encode(); self.send_response(200); self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(body))); self.send_header("Content-Security-Policy","default-src 'none'"); self.end_headers(); self.wfile.write(body)
if __name__=="__main__":
 print("CORTEX app platform: http://127.0.0.1:8080"); HTTPServer(("127.0.0.1",8080),H).serve_forever()
