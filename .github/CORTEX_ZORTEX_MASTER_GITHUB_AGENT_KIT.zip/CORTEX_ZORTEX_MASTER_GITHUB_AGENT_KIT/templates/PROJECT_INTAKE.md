# Universal Project Intake

Project name:
Purpose:
Repository:
Branch:
Language:
Platform:
Modules:
External services:
Credentials available:
Hardware available:
Safety boundaries:
Required outputs:
Testing requirements:
Release target:
Known blockers:
