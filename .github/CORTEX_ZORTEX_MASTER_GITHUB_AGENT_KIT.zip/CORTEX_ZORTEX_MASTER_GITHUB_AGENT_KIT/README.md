# CORTEX / CODEX / VORTEX / ZORTEX Master GitHub Agent Kit

Portable Motorola-friendly kit for one-prompt repository builds.

## Quick start

1. Copy this kit into a Git repository.
2. Run `bash scripts/preflight.sh`.
3. Run `bash scripts/run_agent.sh`.

The launcher reads the full prompt from a file, avoiding giant phone pastes.

No secrets, credentials, personal data, or device identifiers are included.
