from __future__ import annotations

import json
import re
from pathlib import Path

from .models import AssistantResponse, EvidenceItem, PlanItem, utc_now
from .policy import validate_command
from .providers import load_provider


class AssistantEngine:
    def __init__(self, root: Path, provider_name: str = "mock") -> None:
        self.root = root.resolve()
        self.provider = load_provider(provider_name)
        self.audit_dir = self.root / "artifacts" / "assistant"
        self.audit_dir.mkdir(parents=True, exist_ok=True)

    def ask(self, query: str) -> AssistantResponse:
        evidence = self.search(query)
        context = "\n".join(
            f"{item.path}:{item.line or 0}: {item.excerpt}"
            for item in evidence[:20]
        )

        answer = self.provider.summarize(query, context)
        response = AssistantResponse(
            query=query,
            answer=answer,
            evidence=evidence,
            missing_evidence=[] if evidence else [
                "No matching repository evidence was found."
            ],
            recommendations=[
                "Review the cited files before changing code.",
                "Run tests after any approved modification.",
            ],
        )
        self._audit("ask", response.to_dict())
        return response

    def explain(self, text: str) -> AssistantResponse:
        lowered = text.lower()
        evidence = self.search(text)
        recommendations: list[str] = []
        inference: list[str] = []

        if "modulenotfounderror" in lowered:
            inference.append(
                "The installed package or Python import path may not include "
                "the referenced module."
            )
            recommendations.extend([
                "Confirm the expected file exists.",
                "Run: python -m pip install -e .",
                "Run the smallest failing test first.",
            ])
        elif "filenotfounderror" in lowered or "no such file" in lowered:
            inference.append(
                "The command is likely using a filename or directory that "
                "does not exist at the current working location."
            )
            recommendations.extend([
                "Run pwd.",
                "Run find . -maxdepth 3 -iname '*keyword*'.",
                "Use the exact returned path.",
            ])
        else:
            inference.append(
                "No specialized deterministic explanation matched the input."
            )
            recommendations.append(
                "Search the repository and inspect the first failing traceback."
            )

        response = AssistantResponse(
            query=text,
            answer="Deterministic mock-mode failure explanation.",
            evidence=evidence,
            inference=inference,
            recommendations=recommendations,
        )
        self._audit("explain", response.to_dict())
        return response

    def plan(self, goal: str) -> list[PlanItem]:
        normalized = goal.lower()
        items: list[PlanItem] = [
            PlanItem(1, "Inspect repository status", ["git", "status", "--short"]),
            PlanItem(2, "Review graph summary", [
                "python", "scripts/zortex_graph.py", "summary"
            ]),
            PlanItem(3, "Run tests", ["python", "-m", "pytest", "-q"]),
        ]

        if any(term in normalized for term in {
            "flash", "erase", "unlock", "format", "repartition"
        }):
            items.append(
                PlanItem(
                    4,
                    "Reject device-mutating request",
                    [],
                    requires_approval=False,
                    status="blocked",
                )
            )

        validated: list[PlanItem] = []
        for item in items:
            if not item.command:
                validated.append(item)
                continue
            allowed, message = validate_command(item.command)
            validated.append(
                PlanItem(
                    order=item.order,
                    action=f"{item.action}: {message}",
                    command=item.command,
                    requires_approval=True,
                    status="proposed" if allowed else "blocked",
                )
            )

        self._audit("plan", {
            "goal": goal,
            "items": [item.to_dict() for item in validated],
            "generated_at": utc_now(),
        })
        return validated

    def status(self) -> dict[str, object]:
        records = sorted(self.audit_dir.glob("*.json"))
        return {
            "provider": self.provider.name,
            "mode": "local-first",
            "automatic_shell_execution": False,
            "human_approval_required": True,
            "audit_record_count": len(records),
            "latest_audit": records[-1].name if records else None,
        }

    def search(self, query: str, limit: int = 20) -> list[EvidenceItem]:
        tokens = [
            token.lower()
            for token in re.findall(r"[A-Za-z0-9_./-]+", query)
            if len(token) >= 3
        ]
        if not tokens:
            return []

        ignored = {
            ".git", ".venv", "__pycache__", ".pytest_cache",
            ".ruff_cache", "node_modules",
        }
        results: list[EvidenceItem] = []

        for path in sorted(self.root.rglob("*")):
            if len(results) >= limit:
                break
            if not path.is_file():
                continue
            if any(part in ignored for part in path.parts):
                continue
            if path.suffix.lower() not in {
                ".py", ".md", ".txt", ".json", ".toml", ".yml", ".yaml"
            }:
                continue

            try:
                lines = path.read_text(
                    encoding="utf-8",
                    errors="ignore",
                ).splitlines()
            except OSError:
                continue

            relative = path.relative_to(self.root).as_posix()
            for number, line in enumerate(lines, start=1):
                haystack = f"{relative} {line}".lower()
                if any(token in haystack for token in tokens):
                    results.append(
                        EvidenceItem(
                            path=relative,
                            line=number,
                            excerpt=line.strip()[:300],
                        )
                    )
                    if len(results) >= limit:
                        break

        return results

    def _audit(self, action: str, payload: dict[str, object]) -> Path:
        index = len(list(self.audit_dir.glob("*.json"))) + 1
        path = self.audit_dir / f"{index:04d}-{action}.json"
        path.write_text(
            json.dumps(payload, indent=2) + "\n",
            encoding="utf-8",
        )
        return path
