from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol


class Provider(Protocol):
    name: str

    def summarize(self, prompt: str, context: str) -> str:
        ...


@dataclass
class MockProvider:
    name: str = "mock"

    def summarize(self, prompt: str, context: str) -> str:
        context = context.strip()
        if not context:
            return "No verified repository context was available."
        preview = context[:1200]
        return (
            "Mock-mode summary based only on repository evidence:\n"
            f"{preview}"
        )


def load_provider(name: str | None) -> Provider:
    normalized = (name or "mock").strip().lower()
    if normalized != "mock":
        raise RuntimeError(
            "External AI providers are disabled until an explicit adapter "
            "and environment-variable gate are configured."
        )
    return MockProvider()
