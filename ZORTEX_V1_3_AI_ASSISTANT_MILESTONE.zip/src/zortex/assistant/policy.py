from __future__ import annotations

BLOCK_MESSAGE = "BLOCKED: authorized restoration gate has not been satisfied."

SAFE_COMMANDS: set[tuple[str, ...]] = {
    ("git", "status"),
    ("git", "status", "--short"),
    ("pytest", "-q"),
    ("python", "-m", "pytest", "-q"),
    ("python", "scripts/zortex_graph.py", "summary"),
    ("python", "scripts/zortex_graph.py", "missing-evidence"),
}

DENIED_TERMS = {
    "flash",
    "erase",
    "format",
    "unlock",
    "repartition",
    "force-push",
    "reset --hard",
    "rm -rf",
    "adb root",
    "fastboot flashing",
}


def validate_command(command: list[str]) -> tuple[bool, str]:
    normalized = " ".join(command).strip().lower()

    if any(term in normalized for term in DENIED_TERMS):
        return False, BLOCK_MESSAGE

    if tuple(command) not in SAFE_COMMANDS:
        return False, "BLOCKED: command is not on the assistant allowlist."

    return True, "approved-for-human-review"
