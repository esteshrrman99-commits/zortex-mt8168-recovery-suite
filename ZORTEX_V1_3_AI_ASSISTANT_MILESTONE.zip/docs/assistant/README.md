# ZORTEX v1.3 AI Assistant Console

The assistant is local-first, deterministic in mock mode, repository-scoped,
and unable to execute shell commands automatically.

## Commands

```bash
python scripts/zortex_assistant.py ask "knowledge graph"
python scripts/zortex_assistant.py explain "FileNotFoundError"
python scripts/zortex_assistant.py plan "check repository health"
python scripts/zortex_assistant.py status
```

## Guarantees

- repository data only;
- no mandatory paid API;
- deterministic mock provider;
- no automatic shell execution;
- human approval required for every proposed command;
- allowlisted commands only;
- complete JSON audit trail;
- verified evidence, inference, missing evidence, recommendations, and blocked
  operations are separated.

## Audit location

```text
artifacts/assistant/
```

## External providers

External providers are disabled by default. A future adapter must require:
- an explicit provider implementation;
- environment-variable checks;
- no credentials in Git;
- a documented privacy boundary;
- test coverage;
- human approval for every command plan.
