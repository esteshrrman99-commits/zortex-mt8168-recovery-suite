from pathlib import Path

from zortex.assistant import AssistantEngine
from zortex.assistant.policy import BLOCK_MESSAGE, validate_command


def test_assistant_searches_repository(tmp_path: Path) -> None:
    (tmp_path / "README.md").write_text(
        "Knowledge graph milestone complete.\n",
        encoding="utf-8",
    )
    engine = AssistantEngine(tmp_path)
    response = engine.ask("knowledge graph")
    assert response.evidence
    assert response.evidence[0].path == "README.md"


def test_assistant_explains_missing_file(tmp_path: Path) -> None:
    engine = AssistantEngine(tmp_path)
    response = engine.explain("FileNotFoundError: no such file")
    assert response.inference
    assert any("pwd" in item.lower() for item in response.recommendations)


def test_plan_requires_human_approval(tmp_path: Path) -> None:
    engine = AssistantEngine(tmp_path)
    plan = engine.plan("check repository")
    assert plan
    assert all(item.requires_approval for item in plan if item.command)


def test_mutating_command_is_blocked() -> None:
    allowed, message = validate_command(["fastboot", "flashing", "unlock"])
    assert allowed is False
    assert message == BLOCK_MESSAGE


def test_status_reports_mock_mode(tmp_path: Path) -> None:
    engine = AssistantEngine(tmp_path)
    status = engine.status()
    assert status["provider"] == "mock"
    assert status["automatic_shell_execution"] is False
