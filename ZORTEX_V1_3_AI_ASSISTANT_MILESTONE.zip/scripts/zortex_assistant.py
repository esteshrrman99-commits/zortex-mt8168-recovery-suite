#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from zortex.assistant import AssistantEngine


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="ZORTEX v1.3 local-first assistant"
    )
    sub = parser.add_subparsers(dest="command", required=True)

    ask = sub.add_parser("ask")
    ask.add_argument("query", nargs="+")

    explain = sub.add_parser("explain")
    explain.add_argument("text", nargs="+")

    plan = sub.add_parser("plan")
    plan.add_argument("goal", nargs="+")

    sub.add_parser("status")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    provider = os.environ.get("ZORTEX_AI_PROVIDER", "mock")
    engine = AssistantEngine(ROOT, provider_name=provider)

    if args.command == "ask":
        response = engine.ask(" ".join(args.query))
        print(json.dumps(response.to_dict(), indent=2))
        return 0

    if args.command == "explain":
        response = engine.explain(" ".join(args.text))
        print(json.dumps(response.to_dict(), indent=2))
        return 0

    if args.command == "plan":
        items = engine.plan(" ".join(args.goal))
        print(json.dumps([item.to_dict() for item in items], indent=2))
        return 0

    if args.command == "status":
        print(json.dumps(engine.status(), indent=2))
        return 0

    return 2


if __name__ == "__main__":
    raise SystemExit(main())
